lista_nomes = []
lista_idades = []
lista_salarios = []
lista_classe = []
pessoas = 0
nome = input("Digite o nome da primeira pessoa: ")
lista_nomes.append(nome)
idade = int(input("Digite a idade da primeira pessoa: "))
while idade != 0:
    pessoas += 1
    lista_idades.append(idade)
    salario = float(input("Digite o salário dessa pessoa: "))
    lista_salarios.append(salario)
    if salario <= 1302:
        classe = "pobríssimo"
        lista_classe.append(classe)
    elif salario <= 5000:
        classe = "pobre"
        lista_classe.append(classe)
    elif salario <= 10000:
        classe = "classe média"
        lista_classe.append(classe)
    elif salario > 10000:
        classe = "riquin"
        lista_classe.append(classe)
    nome = input("Digite o nome de outra pessoa: ")
    lista_nomes.append(nome)
    idade = int(input("Digite a idade dessa pessoa: "))
    richest = lista_salarios.index(max(lista_salarios))
    poorest = lista_salarios.index(min(lista_salarios))
print("Dentre uma lista de", pessoas ,"pessoas, a que possui o maior salário é", lista_nomes[richest] ,", que possui um salário de R$", max(lista_salarios) ,"aos", lista_idades[richest] , "anos de idade, portanto é", lista_classe[richest] , ".")
print("Dentre uma lista de", pessoas ,"pessoas, a que possui o menor salário é", lista_nomes[poorest] ,", que possui um salário de R$", min(lista_salarios) ," aos", lista_idades[poorest] , "anos de idade, portanto é", lista_classe[poorest] , ".")