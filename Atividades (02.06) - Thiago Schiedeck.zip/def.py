def soma(x,y):
    print(f"Soma de {x} + {y} = {x+y}")
    
def subtracao():
    x = float(input("Digite um valor: "))
    y = float(input("Digite outro valor: "))
    print(f"Subtração de {x} - {y} = {x-y}")

def multiplicacao(x,y):
    return x*y
    
def divisao():
    x = float(input("Digite um valor: "))
    y = float(input("Digite outro valor: "))
    z = x/y
    return (x,y,z)
    
a = float(input("Digite um número: "))
b = float(input("Digite outro número: "))
print("")
soma(a,b)
print("")
print("Agora defina os valores para uma subtração")
print("")
subtracao()
print("")
print("Agora defina os valores para uma multiplicação")
print("")
x = float(input("Digite um valor: "))
y = float(input("Digite outro valor: "))
print("")
print(f"Multiplicação de {x} * {y} = {multiplicacao(x,y)}")
print("")
print("Agora defina os valores para uma divisão")
print("")
x,y,z = divisao()
print("")
print(f"Divisão de {x} / {y} = {z}")
print("FIM")