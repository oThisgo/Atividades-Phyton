def soma(x,y,z):
    print(f"Soma de {x} + {y} + {z} = {x+y+z}")
    
x = float(input("Digite o valor 1: "))
y = float(input("Digite o valor 2: "))
z = float(input("Digite o valor 3: "))

soma(x,y,z)