def valor():
    x = float(input("Digite um valor: "))
    return (x)
if valor() > 0:
    print("P")
elif valor() <= 0:
    print("N")