def somaImposto():
    custo = float(input("Digite o custo do produto: R$"))
    taxaImposto = float(input("Digite a taxa de imposto (%): "))
    return(custo + (custo/100*taxaImposto))
print("")
print("Valor final do produto é R$", somaImposto())