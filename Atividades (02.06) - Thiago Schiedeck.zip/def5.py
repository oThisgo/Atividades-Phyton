nomes=[]
idades=[]
def insere():
    while True:
        nome=input("Digite um nome (Fim=Encerra): ")
        if nome.upper()=="FIM":
            break
        idade=int(input("Disgite a Idade da Pessoa"))
        nomes.append(nome)
        idades.append(idade)

def lista():
    print("\n\n*************** Listar *****************")
    for i in range(len(nomes)):
        print (f"{nomes[i]} tem idade {idades[i]}")
    print("***************************************\n\n")
    
def maiorIdade():
    maior = idades.index(max(idades))
    print(f"A pessoa com maior idade é {nomes[maior]}, com {idades[maior]} anos de idade.")
    
def menorIdade():
    menor = idades.index(min(idades))
    print(f"A pessoa com menor idade é {nomes[menor]}, com {idades[menor]} anos de idade.")
    
def menu():
    print("-"*24)
    print(" 1 - Insere Dados ")
    print(" 2 - Lista Dados")
    print(" 3 - Maior Idade")
    print(" 4 - Menor Idade")
    print(" 9 - FIM")
    print("Escolha Uma Opção:")
#inicio
while True:
    menu()
    opcao=int(input())
    if opcao==9:
        break
    elif opcao == 1:
        insere()
    elif opcao == 2:
        lista()
    elif opcao == 3:
        maiorIdade()
    elif opcao == 4:
        menorIdade()
   
print("Fim")    
