numeros = []
for i in range (1, 6, 1):
    numero = int(input("Digite um número: "))
    numeros.append(numero)
print("")
print("Lista:")
for x in numeros:
    print (x)
    