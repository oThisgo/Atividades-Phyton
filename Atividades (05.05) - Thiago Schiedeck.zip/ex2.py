numeros = []
for i in range(1,11,1):
    numero = float(input("Digite um número real: "))
    numeros.append(numero)
reversed_list = len(numeros) * -1 -1
print("")
for x in range(-1, reversed_list, -1):
    print(numeros[x])