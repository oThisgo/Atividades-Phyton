numeros = []
soma = 0
numero = int(input("Digite um número: "))
numeros.append(numero)
soma += numero
continuar = input("Deseja continuar? (S/N)")
while continuar.upper() == "S":
    numero = int(input("Digite outro número: "))
    numeros.append(numero)
    soma += numero
    continuar = input("Deseja continuar? (S/N)")
list_size = len(numeros)
media = soma/list_size
print("")
print("Em uma lista de",list_size,"números, a soma de todos eles é igual a",soma,"e a média é de",media)
print("")
print("Números inseridos: ")
for i in numeros:
    print(i)
    