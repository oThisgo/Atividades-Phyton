caracteres = []
consoantes = []

for i in range (0,10,1):
    letra = input("Digite uma letra: ")
    if letra.upper() == "A" or letra.upper() == "E" or letra.upper() == "I" or letra.upper() == "O" or letra.upper() == "U":
        caracteres.append(letra)
    else:
        caracteres.append(letra)
        consoantes.append(letra)

print("Foram digitados", len(caracteres) , "caracteres, dos quais", len(consoantes) , "são consoantes. São elas: ")
print("")
for x in consoantes:
    print(x)