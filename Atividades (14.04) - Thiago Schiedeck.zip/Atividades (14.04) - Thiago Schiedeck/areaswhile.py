i=1
base = float(input("Base do triângulo " + str(i) + ": "))
while base > 0:
    altura = float(input("altura do triângulo " + str(i) + ": "))
    area = base*altura/2
    print("A área do triângulo " + str(i) + " é de",area,"m².")
    i+=1
    base = float(input("Base do triângulo " + str(i) + ": "))
print("FIM")