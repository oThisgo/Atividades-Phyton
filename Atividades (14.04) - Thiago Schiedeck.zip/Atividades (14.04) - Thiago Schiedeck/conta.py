positivo = 0
negativo = 0
valor = float(input("Digite um valor: "))
while valor != 0:
    if valor > 0:
        positivo = positivo + 1
    elif valor < 0:
        negativo += 1
    valor = float(input("Digite um valor: "))
print(positivo,"números positivos e",negativo,"números negativos.")
    