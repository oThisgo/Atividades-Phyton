soma = 0 
for i in range(10):
    print(i)
    soma+=i
print("soma =",soma)
print("#"*20)
i = 0
while i <= 10:
    print(i)
    i+=1