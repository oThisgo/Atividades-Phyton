x = float(input("Digite um valor para X: "))
y = float(input("Digite um valor para Y: "))

if x != 0:
    altx = x
    x = y
    
if y != 0:
    alty = y
    y = altx
    
print("Valores originais")
print("X =",altx)
print("Y =",alty)
print("Valores invertidos")
print("X =",x)
print("Y =",y)
    