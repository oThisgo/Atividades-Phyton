produto = input("Digite o nome do produto: ")
quant = int(input("Digite a quantidade: "))
preco = float(input("Digite o valor unitário do produto: "))
desc = int(input("Digite o valor do desconto (%): "))

porcent = preco / 100 * desc
preco_final = (preco - porcent) * quant

if quant == 1:
    print(quant,"unidade do produto '",produto,"', foi adquirida pelo valor de R$",preco_final,".")
elif quant > 1:
    print(quant,"unidades do produto '",produto,"', foram adquiridas pelo valor de R$",preco_final,".")
else:
    print("Quantidade indisponível :(")