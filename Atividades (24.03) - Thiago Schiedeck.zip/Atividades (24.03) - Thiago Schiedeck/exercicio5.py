baseretangulo = float(input("Digite o valor da base do retângulo (cm): "))
alturaretangulo = float(input("Digite o valor da altura do retângulo (cm): "))
raio = float(input("Digite o valor do raio da circunferência (cm): "))

arearetangulo = baseretangulo * alturaretangulo
areacirculo = 3.14 * (raio ** 2)
arearestante = arearetangulo - areacirculo

print("A área restante no retangulo é de",arearestante,"cm².")
