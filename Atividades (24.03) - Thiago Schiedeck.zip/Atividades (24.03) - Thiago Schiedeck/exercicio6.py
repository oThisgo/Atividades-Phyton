real = float(input("Digite o valor em R$: "))
dolar = float(input("Digite o valor da cotação do dólar: "))
produto = real / dolar

print("O valor do produto em dólares será de: $",produto)