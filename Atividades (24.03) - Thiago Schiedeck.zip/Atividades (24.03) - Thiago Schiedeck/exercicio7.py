valor = float(input("Digite qualquer valor: "))

if valor > 10 and valor < 50:
    print("Parabéns, seu número está entre os sorteados!!!")
else:
    print("Sinto muito, seu número não foi sorteado :(")