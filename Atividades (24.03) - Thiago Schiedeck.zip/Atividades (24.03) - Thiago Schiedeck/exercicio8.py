h = int(input("Digite a hora: "))
minutos = int(input("Digite os minutos: "))
segundos = int(input("Digite os segundos: "))

convert_h = h * 3600
convert_min = minutos * 60

total = convert_h + convert_min + segundos

print("O total estimado em segundos é de: ",total,"segundos.")