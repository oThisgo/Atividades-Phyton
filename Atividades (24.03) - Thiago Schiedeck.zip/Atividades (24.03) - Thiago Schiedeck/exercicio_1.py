celsius = float(input("Digite a temperatura em Celsius: "))
fahrenheit = celsius * 9/5 + 32

print("A temperatura fornecida em Fahrenheit é",fahrenheit,"°F.")