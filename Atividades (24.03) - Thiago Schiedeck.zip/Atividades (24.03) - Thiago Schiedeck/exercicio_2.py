valor1 = float(input("Digite o primeiro valor: "))
valor2 = float(input("Digite o segundo valor: "))
valor3 = float(input("Digite o terceiro valor: "))
valor1_invertido = 0
valor2_invertido = 0
valor3_invertido = 0

while valor1 != 0:
    digito1 = valor1 % 10
    valor1_invertido = valor1_invertido * 10 + digito1
    valor1 //= 10
print(valor1_invertido)

while valor2 != 0:
    digito2 = valor2 % 10
    valor2_invertido = valor2_invertido * 10 + digito2
    valor2 //= 10
print(valor2_invertido)

while valor3 != 0:
    digito3 = valor3 % 10
    valor3_invertido = valor3_invertido * 10 + digito3
    valor3 //= 10
print(valor3_invertido)

soma = valor1_invertido + valor2_invertido + valor3_invertido

print("A soma do inverso dos 3 valores apresentados é",soma,".")

