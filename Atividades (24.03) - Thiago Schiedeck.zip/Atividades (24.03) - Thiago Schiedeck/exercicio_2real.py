valor1 = float(input("Digite o primeiro valor: "))
valor2 = float(input("Digite o segundo valor: "))
valor3 = float(input("Digite o terceiro valor: "))
valor1invertido = valor1/(-1)
valor2invertido = valor2/(-1)
valor3invertido = valor3/(-1)

soma = valor1invertido + valor2invertido + valor3invertido

print("A soma dos inversos dos valores indicados deu",soma,".")