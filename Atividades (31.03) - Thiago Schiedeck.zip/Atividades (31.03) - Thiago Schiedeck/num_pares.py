for x in range(0,21,2):
    print(x)
