par = 0
impar = 0
positivo = 0
negativo = 0
for x in range(0,5,1):
    num = int(input("Digite um número: "))
    resto = num % 2
    if resto == 0:
        par = par + 1
    else:
        impar = impar + 1
print("Positivos: ",positivo)
print("Negativos: ",negativo)
print("Pares: ",par)
print("Ímpares: ",impar)