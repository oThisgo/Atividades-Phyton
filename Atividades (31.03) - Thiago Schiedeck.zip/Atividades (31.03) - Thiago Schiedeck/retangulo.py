for x in range(1,6,1):
    base = int(input("Digite o valor da base do retângulo:"))
    altura = int(input("Digite o valor da altura do retângulo:"))
    perimetro = 2*altura + 2*base
    area = base*altura
    
    print("O retângulo",x,"possui um perímetro de",perimetro,"e uma área de",area,"m².")
    
    