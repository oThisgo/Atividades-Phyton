positivo = 0
negativo = 0
for x in range(0,5,1):
    num = int(input("Digite um número: "))
    if num > 0:
        positivo = positivo + 1
    else:
        negativo = negativo + 1
print("Positivos: ",positivo)
print("Negativos: ",negativo)