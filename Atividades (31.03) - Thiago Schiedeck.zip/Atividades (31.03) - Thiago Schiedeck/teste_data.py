import datetime
today = datetime.datetime.now()
print (today)

segundoAtual = today.second
minutoAtual = today.minute
horaAtual = today.hour
diaAtual = today.day
mesAtual = today.month
anoAtual = today.year

segundoNasc = int(input("Digite seu segundo de nascimento:"))
minutoNasc = int(input("Digite seu minuto de nascimento:"))
horaNasc = int(input("Digite sua hora de nascimento:"))
diaNasc = int(input("Digite seu dia de nascimento:"))
mesNasc = int(input("Digite seu mês de nascimento"))
anoNasc = int(input("Digite seu ano de nascimento:"))

idade_segundo = segundoAtual - segundoNasc
idade_minuto = minutoAtual - minutoNasc
idade_hora = horaAtual - horaNasc
idade_dia = diaAtual - diaNasc
idade_mes = mesAtual - mesNasc
idade_ano = anoAtual - anoNasc

print("Você tem",idade_ano,"anos,",idade_mes,"meses,",idade_dia,"dias,",idade_hora,"horas,",idade_minuto,"minutos e",idade_segundo,"segundos de vida.")