import datetime
today = datetime.datetime.now()
print (today)

anoAtual = today.year
mesAtual = today.month
diaAtual = today.day
print(diaAtual,"/",mesAtual,"/",anoAtual)

for x in range(0,5,1):
    nome = input("Digite seu nome:")
    anoNasc = int(input("Digite seu ano de nascimento:"))
    idade = anoAtual - anoNasc
    print(nome,"tem",idade,"anos de idade.")
print("FIM")